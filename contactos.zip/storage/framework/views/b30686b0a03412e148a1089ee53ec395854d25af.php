

<?php $__env->startSection('content'); ?>

<div class="container">
<?php if(Session::has('Mensaje')): ?><?php echo e(Session::get('Mensaje')); ?>

<?php endif; ?>

<a href="<?php echo e(url('contactos/create')); ?>" class="btn btn-success">Agregar un nuevo contacto</a>
<br/>
<br/>
<table class="table table-light table-hover">

    <thead class="thead-light">
        <tr>
            <th>#</th>
            <th>Foto</th>
            <th>Nombre</th>
            <th>Apellido</th>
            <th>Email</th>
            <th>Nacimiento</th>
            <th>Acciones</th>

        </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $contactos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contacto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($loop->iteration); ?></td>
            <td>
            
            <img src="<?php echo e(asset('storage').'/'.$contacto->Foto); ?>" class="img-thumbnail img-fluid" alt="" width="100">

            
            </td>
            <td><?php echo e($contacto->Nombre); ?></td>
            <td><?php echo e($contacto->Apellido); ?></td>
            <td><?php echo e($contacto->Email); ?></td>
            <td><?php echo e($contacto->Nacimiento); ?></td>
            <td>
            <a class="btn btn-warning" href="<?php echo e(url('/contactos/'.$contacto->id.'/edit')); ?>">Editar</a>

            |
            
            <form method="post" action="<?php echo e(url('/contactos/'.$contacto->id)); ?>" style="display:inline">
            <?php echo e(csrf_field()); ?>

            <?php echo e(method_field('DELETE')); ?>

            <button class="btn btn-danger" type="submit" onclick="return confirm('Borrar?')">Borrar</button>
            </form>

            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Xamp\htdocs\contactos\resources\views/contactos/index.blade.php ENDPATH**/ ?>