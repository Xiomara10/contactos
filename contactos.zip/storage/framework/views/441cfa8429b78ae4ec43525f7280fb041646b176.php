
<div class="form-group">
<label for="Nombre" class="control-label"><?php echo e('Nombre'); ?></label>
<input  type="text" class="form-control <?php echo e($errors->has('Nombre')? 'is-invalid':''); ?>" name="Nombre" id="Nombre" 
value="<?php echo e(isset($contacto->Nombre)?$contacto->Nombre:old('Nombre')); ?>">

<?php echo $errors->first('Nombre','<div class="invalid-feedback">Nombre es requerido</div>'); ?>


</div>

<div class="form-group">

<label for="Apellido" class="control-label"><?php echo e('Apellido'); ?></label>
<input  type="text" class="form-control <?php echo e($errors->has('Apellido')? 'is-invalid':''); ?>" name="Apellido" id="Apellido" value="<?php echo e(isset($contacto->Apellido)?$contacto->Apellido:old('Apellido')); ?>">
<?php echo $errors->first('Apellido','<div class="invalid-feedback">Apellido es requerido</div>'); ?>

</div>

<div class="form-group">
<label for="Email" class="control-label"><?php echo e('Email'); ?></label>
<input  type="email" class="form-control <?php echo e($errors->has('Email')? 'is-invalid':''); ?>" name="Email" id="Email" value="<?php echo e(isset($contacto->Email)?$contacto->Email:old('Email')); ?>">
<?php echo $errors->first('Email','<div class="invalid-feedback">El correo es requerido</div>'); ?>

</div>

<div class="form-group">
<label for="Nacimiento" class="control-label"><?php echo e('Nacimiento'); ?></label>
<input  type="date" class="form-control <?php echo e($errors->has('Nacimiento')? 'is-invalid':''); ?>" name="Nacimiento" id="Nacimiento" value="<?php echo e(isset($contacto->Nacimiento)?$contacto->Nacimiento:old('Nacimiento')); ?>">
<?php echo $errors->first('Nacimiento','<div class="invalid-feedback">Fecha de nacimiento es requerido</div>'); ?>

</div>

<div class="form-group">
<label for="Foto" class="control-label"><?php echo e('Foto'); ?></label>
<?php if(isset($contacto->Foto)): ?>

<img class="img-thumbnail img-fluid" src="<?php echo e(asset('storage').'/'.$contacto->Foto); ?>" alt="" width="200">

<?php endif; ?>
<input class="form-control <?php echo e($errors->has('Foto')? 'is-invalid':''); ?>"  type="file" name="Foto" id="Foto" value="">
<?php echo $errors->first('Foto','<div class="invalid-feedback">Foto es requerido</div>'); ?>

</div>

<input type="submit" class="btn btn-success" value="<?php echo e($Modo=='crear' ? 'Agregar':'Modificar'); ?>">

<a class="btn btn-primary" href="<?php echo e(url('contactos')); ?>">Regresar</a><?php /**PATH E:\Xamp\htdocs\contactos\resources\views/contactos/form.blade.php ENDPATH**/ ?>